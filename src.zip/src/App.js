
import './App.css';
import {Button} from 'semantic-ui-react'
import Todo from './/components/Todo.js';
import Form from './/components/Form.js'
import FilterButton from './/components/FilterButton.js';
import React, {useState} from 'react';
import { nanoid } from "nanoid";


function addTask(name){
  const newTask = {id: "todo-" +nanoid(), name: name, completed: false};
  setTasks([...tasks,newTask]);
}
  
function App(props) {

  const [tasks, setTasks] = useState(props.tasks);

  const taskList = tasks.map(task => (
  <Todo id ={task.id}
     name={task.name}
     completed ={task.completed} 
     key={task.id}
     toggleTaskCompleted={toggleTaskCompleted}
     />
    )
  );
  function toggleTaskCompleted(id){
    const updatedTasks = tasks.map(task => {
      // if this task has the same ID as the edited task
      if (id === task.id) {
        // use object spread to make a new object
        // whose `completed` prop has been inverted
        return {...task, completed: !task.completed}
      }
      return task;
    });
    setTasks(updatedTasks);
  }
  const taskNoun = taskList.length !==1? 'tasks' : 'task';
  const headingText = '${taskList.length} ${tasksNoun} remaining';
  return (
   <div className="todoapp stack-large">
     {/* A heading */}
     <h1>Vernon's To do List v.1.0.0</h1>

     <Form addTask={addTask}/>
   

     <div className='filters btn-group stack-exception'>
       {/* <button type='button' className='btn toggle-btn' aria-pressed='true'>
         <span className='visually-hidden'>Show</span>
         <span>all</span>
         <span className='visually-hidden'>tasks</span>
       </button>
       <button type='button' className='btn toggle-btn' aria-pressed='false'>
       <span className="visually-hidden">Show </span>
          <span>Active</span>
          <span className="visually-hidden"> tasks</span>
        </button>
        <button type="button" className="btn toggle-btn" aria-pressed="false">
          <span className="visually-hidden">Show </span>
          <span>Completed</span>
          <span className="visually-hidden"> tasks</span>

       </button> */}

       <FilterButton/>
       <FilterButton/>
       <FilterButton/>
     </div>



     <h2 id ="list-heading">
        {headingText}
     </h2>

     <ul
        role="list"
        className="todo-list stack-large stack-exception"
        aria-labelledby="list-heading"
      >
        {/* name="" are props or properties to be used to make 
        each Todo unique */}
        {/* <Todo name = "Eat" comleted={false} id="todo-0"/> 
        <Todo name = "Sleep" completed={false} id ="todo-1"/>
        <Todo name = "Repeat" comleted={false} id= "todo-2"/> */}

        {taskList}

      </ul>
   </div>
  );
}

export default App;
